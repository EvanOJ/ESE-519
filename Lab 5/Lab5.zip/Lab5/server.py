from wsgiref.simple_server import make_server
from pyramid.events import NewRequest, subscriber
from pyramid.config import Configurator
from pyramid.response import Response
from pyramid.view import notfound_view_config, view_config
from pyramid.httpexceptions import HTTPNotFound, HTTPFound
import datetime
import os
import mmap
from ctypes import *
import socket
import signal

#HOST = "0.0.0.0"
HOST = "192.168.8.1"
PORT = 8081


def signal_handler(signal, frame):
    print("You pressed ctrl + c !\n")
    sock.close()
    sys.exit(0)




def add_cors_headers_response_callback(event):
    def cors_headers(request, response):
        response.headers.update({
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST,GET,DELETE,PUT,OPTIONS',
        'Access-Control-Allow-Headers': 'Origin, Content-Type, Accept, Authorization',
        'Access-Control-Allow-Credentials': 'true',
        'Access-Control-Max-Age': '60',
        })
    event.request.add_response_callback(cors_headers)
#upenn.pennpacapp.com:8080/?result=asdfasdf
def mainHandler(request):
    f=open("joystick.txt","w")
    f.write(request.GET['result'])
    f.close()
    return Response(request.GET['result']);
if __name__ == "__main__":
        print("Starting up server")
        '''
        with Configurator() as config:
#                config.include('pyramid_retry')
                #config.include('pyramid_redirect')
                #config.add_redirect_rule(r'https://(x)', r'http://(x)')
		#config.add_subscriber(add_cors_headers_response_callback, NewRequest)
                config.add_route("main","/")
                config.add_view(mainHandler, route_name="main")
		config.scan()
		app=config.make_wsgi_app()
	server = make_server(HOST, PORT, app)
	print("Started server on %s:%d" % (HOST,PORT))
	server.serve_forever()
        '''
        signal.signal(signal.SIGINT, signal_handler)
        print("server running at", socket.gethostbyname(socket.gethostname()))
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.bind(('',8081))
        #f = open("joystick.txt", "w")
        '''
        while True:
            print "waiting for udp package ..."
            data, address = sock.recvfrom(256)
            f = open("joystick.txt","w")
            f.write(data)
            f.close()

            print "received package from", address, "with data", data
            #sock.sendto(data, address)
        '''
        fifo_name = "data_fifo"
        '''
        try:
            os.mkfifo(fifo)
        except FileExistsError:
            pass
        '''
        print("fifo")
        f = open(fifo_name, "w", 0)
        print("file open")
        while True:
            print("waiting for upd package ...")
            data, address = sock.recvfrom(256)
            f.write(data)
            print("received pacjage from ", address, "with data", data)
