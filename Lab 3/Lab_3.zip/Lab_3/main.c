	
/*
 * EOJ_lab3.c
 *
 * Created: 9/26/2018 9:11:52 PM
 * Updated: 10/1/2018
 * Author : evan
 */ 

/*Sets up and defines libraries and variables needed to run the code
Includes necessary handles/libraries to run code*/
#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdio.h>
#include <avr/delay.h>
#include "lcd.h"
#include "uart.h"
#include <time.h> 
#include <stdlib.h>
#include <math.h>

//Round number to be updated/displayed each round as signed integer
int roundNum = 1;

//Sets random x and y coordinates initially to 0 as a signed integer
int ranX=0;
int ranY=0;

//Sets x values as unsigned 64bit integers
uint64_t xCoord;

//Sets y values as unsigned 64bit integers
uint64_t xSum=0;

//Sets y values as unsigned 64bit integers
uint64_t yCoord;

/*Sets player score as an 8bit unsigned integer to initially start at 0 while 
hardcoding the round limit per game to 2*/
uint8_t player1Score=0;
uint8_t player2Score=0;
int scoreLimit = 2;

//Direction set as an integer for updating paddle direction
int direction;

//Defines structure of variables for paddle
typedef struct {
	int x, y;
	int w, h;
}paddle_s;

//Defines structure of variables for ball
typedef struct {
	int x, y; // position
	int r; // radius
	int dx, dy; //speed at x and y direction
}ball_s;

void drawBoard(){
	/*Sets up the display for the game.
	Function to draw the game board*/
	drawrect(buff,0,0,128,64,1);												//draw the gameboard boundary
	drawline(buff,64,0,64,64,1);												//draw the gameboard centerline
}

void drawBall(ball_s ball1){
	/*Function to draw the ball*/
	fillcircle(buff,ball1.x,ball1.y,3,1);										//draws filled circle at position x and y with radius of 3
}

void drawPaddles(paddle_s paddle1, paddle_s paddle2){
	/*Function to draw the paddles for both players*/
	fillrect(buff,paddle1.x,paddle1.y,2,12,1);				//draws filled rectangle with position x and y with width and height of 2 and 12 respectively
	fillrect(buff,paddle2.x,paddle2.y,2,12,1);				//draws filled rectangle with position x and y with width and height of 2 and 12 respectively
}

void drawScore(int player1score, int player2score){
	/*Function to draw score of the game*/
	char str[2];														//sets character to be 2 strings long
	drawstring(buff,53,1,itoa(player1score,str,10));					//draws string at position x=53, in line 1 (score integer to a string)
	drawstring(buff,71,1,itoa(player2score,str,10));					//draws string at position x=71, in line 1 (score integer to a string)
	free(str);	
}

void endgameprint(int nscore){
	/*Function to print end-of-game text and player victory indication*/
	clear_buffer(buff);													//clears the buffer
	if(player1Score == nscore){											//if one player's score is equal to the close score 
		drawstring(buff,32,3,"player1 win");							//draws string at x=32 line 3
	}
	else{
		drawstring(buff,32,3,"player2 win");							//otherwise, draws string at x=32 line 3
	}
	write_buffer(buff);													//writes to the buffer
	
	_delay_ms(10000);													//adds delay of 10000milliseconds
	
	clear_buffer(buff);													//clears the buffer
	drawstring(buff,32,3,"reset the game");								//draws string at x-32, line 3
	write_buffer(buff);													//writes to the buffer
}

void blinkScreen(int nblinklimit){
	/*Function to blink the Screen at end of the game*/
	int nblink = 0;														//defines and sets blink variable to initially start at 0
	while(nblink <= nblinklimit){										//while the blink variable is less than or equal to the limit
		PORTB ^= (1<<PORTB2)|(1<<PORTB0);								//toggle PB2 and PB0 on and off
		_delay_ms(10000);												//adds delay of 10000 milliseconds
		nblink = nblink + 1;											//keeps increasing blink variable by one each time loop is run
	}
}

void drawAll(paddle_s paddle1,paddle_s paddle2, ball_s ball1, int player1score, int player2score){
	/*Function to draw all necessary game componenets simultaneously*/
	clear_buffer(buff);															//clears the buffer
	drawBoard();																//uses function drawBoard
	drawPaddles(paddle1,paddle2);												//uses function drawPaddles
	drawBall(ball1);															//uses function drawBall
	drawScore(player1score, player2score);										//uses function drawScore
	write_buffer(buff);															//writes to the buffer
}

void set_up(){
	/*Function to initialize ADC for touchscreen input*/
	ADCSRA = (1<<ADPS2)|(1<<ADPS1);												//Enables ADC s.t. 64 prescaler
	ADCSRB &= ((1<<ADTS2)|(1<<ADTS1)|(1<<ADTS0));								//ADC Control setting timer counter 1 capture
	ADCSRA |= (1<<ADATE);														//Enables auto-trigger
	ADCSRA |= (1<<ADEN);														//Enables  ADC
	DDRC = 0b00001010;															//setup port c register for reading adc for x coordinate read							
}

void calculate_xcord(){
	/*Function to set registers and ADC to calculate x-coordinates based on ADC values*/
	DDRC = 0b000000101;															//set pins for x read (y as outputs)
	ADMUX = 0b01000011;															//Sets PC3 as ADC input, and setting REFs0 to AVcc
	PORTC &= 0b11110000; 														// clear all bits for ADC port
	PORTC |= (1<<PORTC0);														//set (PC0) Y- as output HIGH
	PORTC |= (0<<PORTC2);														//set (PC2) Y+ as output LOW
	PORTC |= (1<<PORTC3);														//A0 (PC0) x- HIGH imped
	PORTC |= (1<<PORTC1);														//A2 (PC2) x+ HIGH imped
}

void calculate_ycord(){
	/*Function to set registers and ADC to calculate y-coordinates based on ADC values*/
	DDRC = 0b00001010;															//set pins for yread
	ADMUX = 0b01000000;		                           						 	//Sets PC0 as ADC input, and setting REFs0 to AVcc
	PORTC &= 0b11110000;                               							//clear all bits for ADC port
	PORTC |= (1<<PORTC3);														//A3 (PC3) x- set HIGH
	PORTC |= (0<<PORTC1);														//A1 (PC1) x+ set low				
	PORTC |= (1<<PORTC0);														//set (PC0) Y- as HIGH imped
	PORTC |= (1<<PORTC2);														//set (PC2) Y+ as HIGh imped
}

paddle_s updatePaddle(paddle_s paddle, int direction){
	/*Function to update the paddle location based on the direction of the input*/
	if(direction==1){															//if the paddle is moving in the positive (up) direction
		//paddle moving up
		if((paddle.y + 13)>63){													//if the y position of the paddle +1 is less than 63 (maximum y direction of screen)
			//check if paddle is going off the board, if yes, dont move it from where it is
			paddle.y = paddle.y;												//update y position of paddle
		}else{
			//else move it 
			paddle.y = paddle.y + direction;									//otherwise, move the paddle in the positive (up) direction (based on +1 of if statement)
		}

	}else if(direction==-1){													//but if direction is negative (down)
		//paddle moving down
		if((paddle.y -1)<1){													//if the y position of the paddle -1 is less than 1 (minimum y direction of screen)
			//check if paddle is going off the board, if yes, dont move it from where it is
			paddle.y = paddle.y;												//update y position of paddle
		}else{
			//else, move it 
			paddle.y = paddle.y + direction;									//otherwise, move the paddle in the negative (down) direction (based on -1 of if statement)
		}
	}
	return paddle;																//return the paddle (aka updates with new placement)
}

int checkDirection(uint64_t yCoord, int side){									//checks the direction (up or down) of the paddle
	/*Function to check the direction of paddle movement*/

	int margin =32;																//sets variable margin as a signed integer to 32(middle of board on y axis)
	
	if(yCoord==0){																//if the y coordinate is equal to zero, it is not moving
		//not moving
		direction = 0;															//direction is set to zero (not moving)
	}
	else if(yCoord>margin){														//otherwise if y coordinate is larger than the margin, it is moving up
		//moving up
		direction = 1;															//direction is +1 (move paddle up)
	}else{
		//moving down
		direction = -1;															//otherwise direction is -1 (move paddle down)
	}	
	return direction;															//updates new direction
}

ball_s Move_ball(ball_s ball){
	/*Function to move the ball on the scree nat a certain speed and direction*/
	ball.x = ball.x + ball.dx; 													// move ball in x direction at horizontal ball speed (dx)
	ball.y = ball.y + ball.dy; 													// move ball in y direction at vertical ball speed (dy)
	return ball;																//updates new ball position
}

int nPaddleHit(paddle_s paddle, ball_s ball){									
	// 0 : hit the paddle
	/*function to indicate paddle hit
	0 : hit the paddle
	1: not hit the paddle*/
	int nReturn = 0;															//defines return as a signed integer and initially sets it to 0
	
	if ((ball.y < paddle.y -1)||(ball.y > paddle.y + paddle.h + 1)){			//if the ball y position is less than paddle y position -1 or greater than the height +1
		nReturn = 1;															//reset return as 1 (did not hit paddle)
	}
	return nReturn;																//update return value
}

int Ball_env_check(ball_s ball, paddle_s paddle_1, paddle_s paddle_2){
	/*//checks the environment of the ball (ball status) based on a 4 quadrant area

	4: not hitting
	3: hitting the boundary of top and down
	2: hitting the boundary left without paddle -> right side win
	1: hitting the boundary right without paddle-> left side win
	0: hitting the boundary left/right with paddle*/
	int nReturn = 4;															//initially sets the return variable at 4 (ball not hitting anything)

	// bottom right
	if (ball.dx > 0 && ball.dy >0){												//if the speed/direction of the ball both for x and y is larger than 0
		if (ball.x == 122){														//if the x position of the ball is equal to 122 (128-6=122 for radius=3 (diameter=6) of the ball) on the right
			nReturn = 2 * nPaddleHit(paddle_2, ball);							//rewrite return value to 2 times return value based on answer from PaddleHit on the right	
		}
		if (ball.y == 60){														//if the y position of the ball is equal to 60 (64-4=60 for width=2 of each paddle)	
			nReturn = 3;														//rewrite the return value to 3 (indicates hitting top and bottom boundaries) on right	
		}
	}

	// top right
	else if(ball.dx > 0 && ball.dy < 0){										//else if ball speed/direction in x  is greater than 0 but less than 0 in y
		if (ball.x == 122){														//if the x position of the ball is equal to 122 (128-6=122 for radius=3 (diameter=6) of the ball) on the right
			nReturn = 2 * nPaddleHit(paddle_2, ball);							//rewrite return value to 2 times return value based on answer from PaddleHit on the right	
		}
		if (ball.y == 3){														//if the y position of the ball is equal to 3 (radius of the ball=3)
			nReturn = 3;														//rewrite return value to 3 (indicates hitting top and bottom boundaries) on right
		}
	}

	// bottom left
	else if (ball.dx < 0 && ball.dy > 0){										//if ball speed/direction in x  is less than zero but greater than zero in y
		if (ball.x == 5){														//if the x position of the ball is 5 (radius of ball (3)+width of paddle (2))
			nReturn = nPaddleHit(paddle_1, ball);								//rewrite return value to 2 times return value based on answer from PaddleHit on the left	
		}
		if (ball.y == 60){														//if the y position of the ball is equal to 60 (64-4=60 for width=2 of each paddle)	
			nReturn = 3;														//rewrite return value to 3 (indicates hitting top and bottom boundaries) on left
		}
	}

	// top left
	else if (ball.dx < 0 && ball.dy < 0){										//if the ball speed/direction in x and y  are both less than 0
		if (ball.x == 5){														//if the x position of the ball is 5 (radius of ball (3)+width of paddle (2))
			nReturn = nPaddleHit(paddle_1, ball);								//rewrite return value to 2 times return value based on answer from PaddleHit on the left	
		}
		if (ball.y == 3){														//if the y position of the ball is equal to 3 (radius of the ball=3)
			nReturn = 3;														//rewrite return value to 3 (indicates hitting top and bottom boundaries) on left
		}
	}
	return nReturn;																//updates the return variable (hit or miss status)
}

ball_s Ball_update(ball_s ball, int status){
	/*Function to update the position of the ball*/
	if(status == 0){															//if status is equal to 0
		ball.dx = -ball.dx;														//update ball speed/direction to move in opposite x-direction
	}
	if(status == 3){															//if status is equal to 3
		ball.dy = -ball.dy;														//update ball speed/direction to move in opposite y-direction
	}
	return ball;																//returns updated ball 
}

ball_s startGame(ball_s ball){
	/*Function to initialize start gameplay, center ball, and start moving ball 
	in random ball direction*/
	//start the game
	clear_buffer(buff);															//clears the buffer
	drawstring(buff,34,3,"ROUND: ");											//draws a string for the round label
	drawchar(buff,80,3,roundNum+'0');											//draws a character after the string for round number
	drawBoard();																//uses function drawBoard to draw game board
	
	write_buffer(buff);															//writes to the buffer
	_delay_ms(10000);															//adds a delay of 10000 milliseconds
	clear_buffer(buff);															//clears the buffer

	ranX = (rand() % 100 + (-50));												//init random number for to use for Dx initialization
	ranY = (rand() % 100 + (-50));												//init random number for to use for Dy initialization

	if(ranX>0){																	//neither can equal 0 or else ball will not move
		ball.dx = 1;															//set ball irection in x to 1
	}
	else{
		ball.dx = -1;															//otherwise set direction of the ball in x to -1
	}

	if(ranY>0){																	//if the random y direction is larger than 0
		ball.dy =  1;															//set ball direction in y to 1
	}else{
		ball.dy = -1;															//set ball direction in y to -1
	}

	ball.x = 64;																//re-center ball for x
	ball.y = 32;																//re-center ball for y
	
	return ball;																//return updated ball
}

void buzz(){
	/*Function to toggle power to the buzzer, playing a noise at a predefined frequency*/
	PORTB ^= (1 << PORTB5);														//toggles PB5 on
	_delay_ms(1000);															//adds a delay of 1000 milliseconds
	PORTB ^= (1 << PORTB5);														//toggles PB5 off
}

void flashAndBuzz(){
	/*Function to toggle power to the buzzer, and toggle power to blue
	LCD screen backlights*/
	PORTB ^= (1<<PORTB2);														//toggles PB2 on
	buzz();																		//runs buzzer
	PORTB ^= (1<<PORTB2);														//toggles PB2 off
}

ISR(TIMER1_COMPA_vect){
	/*The timer counter reset here is not necessary due to CTC mode, but we 
	left it in just in case, as this helped during lab 2. The OC1A pin is set 
	to toggle mode so this will generate the PWM at the predetermined freq.*/
	TCNT1 = 0;																	//reset timer counter 1 value to 0 
}

int main(void){

	//setup registers for the backlight of the LCD - Red, Blue and Green - all on
	DDRD |= 0x80; 																//sets PD6 as output
	PORTD &= ~0x80;																//set PD6 as HIGH
	PORTD |= 0x00;																//sets bits for ports
	
	DDRB |= 0x27; 																//sets PB0, PB1, PB2, & PB5 as outputs (screen and buzzer)
	PORTB &= ~0x05; 															//set PB0 & PB2 as HIGH
	PORTB |= 0x00;																//sets bits for ports
	sei();	//enable global interrupts

	// set up timer for output compare needed for buzzer frequency adjustmet
	TCCR1B |= (1 << WGM12)|(1 << CS11); 										//CTC mode w/ 8 bit prescaler
	TCNT1 = 0;																	//initial timer count value to 0
	TCCR1A |= (1 << COM1A0);   													// toggle OC1A compare match
	TIMSK1 |= (1 << OCIE1A); 													//output compare mode
	
	uart_init();																//initalizes uart for serial communication
	
	//lcd initialisation
	lcd_init();																	//initializes LCD
	lcd_command(CMD_DISPLAY_ON);												//allows display/command (see lcd.c library)
	lcd_set_brightness(0x18);													//sets brightness of LCD
	write_buffer(buff);															//writes to buffer
	_delay_ms(10000);															//adds delay of 10000 milliseconds

	clear_buffer(buff);															//clears the buffer
	paddle_s paddle1;															//initializes left player 1 paddle
	paddle_s paddle2;															//initializes left player 2 paddle
						
	paddle1.x = 1;																//sets x position of left paddle to 1 (left side)
	paddle1.y = 32;																//sets y position of left paddle to 32 (middle)
	paddle1.h = 12;																//sets height of left paddle to 12

	paddle2.x = 125;															//sets x position of right paddle to 125 (right side)
	paddle2.y = 32;																//sets y position of right paddle to 32 (middle)
	paddle2.h = 12;																//sets height of right paddle to 12
	
	ball_s ball1;																//initialize game ball
	
	ball1.x=64;																	//sets x position of the ball to 64 (centered on x)
	ball1.y=32;																	//sets y position of the ball to 32 (centered on y)

	set_up();																	//runs setup function

	ball1 = startGame(ball1);													//runs startGame function using defined ball 
	
	/*
	1:play accelerometer game mode
	2:play touchscreen game mode
	*/
	int nMode = 2;																//indicates mode s.t. 2 is touchscreen game mode
	
	while(1){
		
		if (nMode ==1){
			ADMUX = 0b01000100;	 												//change to ADC4 pin for accelerometer
			while ((player1Score < scoreLimit)&&(player2Score <scoreLimit))
			{
				while (1)														//loop forever
				{
					clear_buffer(buff);
					ADCSRA |= (1<<ADSC);	//Start single conversion
					while(!(ADCSRA & (1<<ADIF))); 								//Wait for conversion to complete s.t. interrupt bit is 1 until done
				
					ball1 = Move_ball(ball1);									//Update the position of the ball

					//player controls paddle 1
					/*Between 343 and 346 constitutes signal noise measured on 
					flat surface moving average filter would resolve
					this as well.*/
					if(ADC>346){												//if ADC value is larger than 346
						direction = -1;											//change the direction to -1 (down)
						paddle1 = updatePaddle(paddle1,direction);				//updates the left paddle
					}
					else if(ADC<343){											//if ADC value is less than 343
						direction = 1;											//change the direction to +1 (up)
						paddle1 = updatePaddle(paddle1,direction);				//updates the left paddle
					}
					else{
						direction=0;											//otherwise set direction to 0 (no movement)
						paddle1=updatePaddle(paddle1,direction);				//updates the left paddle
					}

					//computer controls paddle 2
					/*Computer only responds once ball is passed 75 on axis, 
					and only if the distance between its current paddle position 
					and the ball is great than 24. These two vlaues could be set
					as user inputs to set game difficulty.*/
					if(ball1.x>=75 && ball1.x <128){							//if the x position of the ball is greater than equal to 75 but less than 128 (past middle point on right)
						if((ball1.y - paddle2.y)>24){							//if the y position of the ball - the y position of the right paddle is greater than 24		
							direction = 0;										//set direction to 0 (no movement)
							paddle2 = updatePaddle(paddle2,direction);			//updates the right paddle
						}
					else{
						direction=ball1.dy;										//sets direction of the ball to match the y speed/direction of the ball
						paddle2 = updatePaddle(paddle2,direction);				//updates the right paddle
						}
					}

					int status = Ball_env_check(ball1, paddle1, paddle2);		//checks the status of the ball
					/*
					4: not hitting
					3: hitting the boundary of top and down
					2: hitting the boundary left without paddle -> right side win
					1: hitting the boundary right without paddle-> left side win
					0: hitting the boundary left/right with paddle
					*/
					if (status == 1){											//if left side wins round
						OCR1A = 70;												//OCR1A value is set to tone 1: clock ticks using 16 bit prescaler(frequency set to certain pitch)
						flashAndBuzz();											//runs flash and buzz function
						player1Score = player1Score + 1;						//increases left score by one
						roundNum ++;											//incrementally increases rounds counter
						break;													//breaks from this loop
					}
				
					if (status == 2){											//if right side wins
						OCR1A = 60;												//buzzer pitch is changed tone 2: OCR1A value is set to clock ticks using 16 bit prescaler(frequency set to certain pitch)					
						flashAndBuzz();											//runs flash and buzz function
						player2Score = player2Score + 1;						//increases right score by one
						roundNum ++;											//incrementally increases rounds counter
						break;													//breaks from this loop
					}
					
					if (status ==3){											//if the ball is hitting the top and bottom boundaries
						OCR1A = 50;												//buzzer pitch is changed tone 3: OCR1A value is set to clock ticks using 16 bit prescaler(frequency set to certain pitch)
						buzz();													//runs buzz function for sound											
					}
					
					if (status == 0){											//if the ball is hitting the paddle
						OCR1A = 40;												//buzzer pitch is changed again tone 4: OCR1A value is set to clock ticks using 16 bit prescaler(frequency set to certain pitch)
						buzz();													//runs buzz function for sound										
					}
					
					ball1 = Ball_update(ball1, status);							//ball status is updated
				
					drawAll(paddle1,paddle2, ball1, player1Score, player2Score);//draws all game components at once
				 
					_delay_ms(500);												//adds a delay of 500 milliseconds between ADC read x and y to mitigate noise
				}
			_delay_ms(100);														//adds a delay of 100 milliseconds before next round
			ball1 = startGame(ball1);											//starts next round
			paddle1.y = 32;														//resets paddle position 1 centered on gameboard 
			paddle2.y = 32;														//resets paddle position 2 centered on gameboard 
			srand(ball1.y);														//set new seed for random generator using the ball's last y coordinate 

			drawAll(paddle1,paddle2,ball1, player1Score, player2Score); 		//restart gameplay with updated scores
			}

			clear_buffer(buff);														//clears the buffer
			drawstring(buff,32,3,"GAME OVER!");										//draws a string indicating end of game
			write_buffer(buff);														//writes to buffer
			blinkScreen(3);															//runs blinkScreen function, blinks red
		}
	
		//play game using touchpad input, i.e. human vs human
		if (nMode == 2){
	
			while ((player1Score < scoreLimit)&&(player2Score < scoreLimit))	//if both scores are less than the round limit (no one has one yet)
	
			{		
				// play one round of the game 		
				while (1)														//loop forever 
				{		
					clear_buffer(buff);											//clears the buffer
					ADCSRA |= (1<<ADSC);										//starts single ADC conversion
					calculate_xcord();											//calculates x-coordinate
					_delay_ms(10);
					while(!(ADCSRA & (1<<ADIF))); 								//Wait for conversion to complete s.t. interrupt bit is 1 until done
										
 					if(abs(1024 -ADC) < 15){									//calculates for the scaled and calibrate x-coordinate
 						xCoord = 0;												//accounts for overlapping position of touchpad on lcd, accepts input only above the lcd screen
 					}
 					else{
 						xCoord = 128 - ceil((ADC - 230.0) / (850 -230) * 128);	//calibrated xcoord mapped to the LCD screen
 					}
					
					//printf("x %d\n", xCoord);									//print the resultant x coordinate 													//delay between y coord calc and next xcord calc
			
					calculate_ycord();											//calculates for y coordinate
					_delay_ms(10);												//delay between y coord calc and next xcord calc
			
					while(!(ADCSRA & (1<<ADIF))); 								//Wait for conversion to complete s.t. interrupt bit is 1 until done
																
					if (abs(ADC - 1016) < 10){									//calculates for the scaled and calibrate x-coordinate
						yCoord = 0;												//accounts for overlapping position of touchpad on lcd, accepts input only above the lcd screen
					}
					else{
						yCoord = ceil((ADC -280.0)/ (650 - 280) * 64);			//calibrated xcoord mapped to the LCD screen
					}
					
					//printf("y %d\n",yCoord);									//print the resultant y coordinate
					
					ball1 = Move_ball(ball1);									//updates the position of the ball

					//check for player input, and update respective player's paddle
					if(xCoord < 64){											//if xcord is left of the gameboard centerline = player 1
						//left side player 1
						direction = checkDirection(yCoord,1);					//check the y direction			
						paddle1 = updatePaddle(paddle1,direction);				//update the position of the paddle
					}
					else if (xCoord !=0){
						//player 2
						direction = checkDirection(yCoord,0);					//check the y direction
						paddle2 = updatePaddle(paddle2,direction);				//update position of the right paddle
					}

					int status = Ball_env_check(ball1, paddle1, paddle2);		//checks the ball status

					if (status == 1){											//if left side (player 1) won this round...
						player1Score = player1Score + 1;						//increase left score by 1
						OCR1A = 70;												//buzzer pitch is changed tone 1: OCR1A value is set to clock ticks using 16 bit prescaler(frequency set to certain pitch)
						flashAndBuzz();											//runs flash and buzz function									
						roundNum++;												//incrementally increases rounds counter
						break;													//breaks from this loop
					}
			
					if (status == 2){											//if right side (player 2) won this round...
						player2Score = player2Score + 1;						//incerement player 2 score
						OCR1A = 60;												//buzzer pitch is changed tone 2: OCR1A value is set to clock ticks using 16 bit prescaler(frequency set to certain pitch)
						flashAndBuzz();											//runs buzz and flash function
						roundNum++;												//increment round number
						break;													//break from this loop
					}

					if (status ==3){											//if the ball is hitting the top or bottom boundaries								
						OCR1A = 50;												//buzzer pitch is changed tone 3: OCR1A value is set to clock ticks using 16 bit prescaler(frequency set to certain pitch)									
						buzz();													//run buzz function only
					}
					
					if (status == 0){											//if the ball is hitting a paddle
						OCR1A = 40;												//buzzer pitch is changed tone 4: OCR1A value is set to clock ticks using 16 bit prescaler(frequency set to certain pitch)
						buzz();													//run buzz function only
					}
					
					ball1 = Ball_update(ball1, status);							//updates the position of the ball

					drawAll(paddle1,paddle2, ball1, player1Score, player2Score);//draws all of the game components at once 
				
					_delay_ms(10);												//delay between x coord calc and next ycord calc		
				}
				_delay_ms(100);													//adds a delay of 100 milliseconds between rounds
				ball1 = startGame(ball1);										//starts next round with random ball direction
				paddle1.y = 32;													//reset paddle 1 at center 
				paddle2.y = 32;													//resent paddle 2 at center 
				drawAll(paddle1,paddle2,ball1, player1Score, player2Score); 	//draw all game components, restart of the game with a updated scores
			}
			//round limit has been reached game is over 
			clear_buffer(buff);													//clear lcd write_buffer
			drawstring(buff,32,3,"GAME OVER!");									//draws a string indicating end of game							
			write_buffer(buff);													//writes to buffer
			blinkScreen(3);														//run function to the blink the lcd screen 3 times and change backlight to red
		}

		// display the result of the game (end of game/reset)
		endgameprint(scoreLimit);												//function to indicate end of game when scorelimit reached
		player1Score = 0;														//reset player 1 score to 0
		player2Score = 0;														//reset player 2 score to 0
		roundNum = 1;															//reset round number to 1 (beginning of new game)
	}
}

